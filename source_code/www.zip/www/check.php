<?PHP

phpinfo();
?>
